(self["webpackChunkessaionicapp2"] = self["webpackChunkessaionicapp2"] || []).push([["src_app_customers_all-customers_all-customers_module_ts"],{

/***/ 9586:
/*!*************************************************************************!*\
  !*** ./src/app/customers/all-customers/all-customers-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AllCustomersPageRoutingModule": () => (/* binding */ AllCustomersPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9535);
/* harmony import */ var _all_customers_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./all-customers.page */ 8090);




const routes = [
    {
        path: '',
        component: _all_customers_page__WEBPACK_IMPORTED_MODULE_0__.AllCustomersPage
    }
];
let AllCustomersPageRoutingModule = class AllCustomersPageRoutingModule {
};
AllCustomersPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AllCustomersPageRoutingModule);



/***/ }),

/***/ 8119:
/*!*****************************************************************!*\
  !*** ./src/app/customers/all-customers/all-customers.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AllCustomersPageModule": () => (/* binding */ AllCustomersPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4595);
/* harmony import */ var _all_customers_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./all-customers-routing.module */ 9586);
/* harmony import */ var _all_customers_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./all-customers.page */ 8090);







let AllCustomersPageModule = class AllCustomersPageModule {
};
AllCustomersPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _all_customers_routing_module__WEBPACK_IMPORTED_MODULE_0__.AllCustomersPageRoutingModule
        ],
        declarations: [_all_customers_page__WEBPACK_IMPORTED_MODULE_1__.AllCustomersPage]
    })
], AllCustomersPageModule);



/***/ }),

/***/ 8090:
/*!***************************************************************!*\
  !*** ./src/app/customers/all-customers/all-customers.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AllCustomersPage": () => (/* binding */ AllCustomersPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 1855);
/* harmony import */ var _raw_loader_all_customers_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./all-customers.page.html */ 2857);
/* harmony import */ var _all_customers_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./all-customers.page.scss */ 9289);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2741);
/* harmony import */ var src_app_shared_customer_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/customer-service.service */ 2588);





let AllCustomersPage = class AllCustomersPage {
    constructor(customerService) {
        this.customerService = customerService;
        this.htmlData = [];
    }
    ngOnInit() {
        let customerRes = this.customerService.getAllCustomer();
        customerRes.snapshotChanges().subscribe(res => {
            this.allcustomers = res;
            this.allcustomers.payload.forEach(item => {
                console.log(item.toJSON());
                this.htmlData.push(item.toJSON());
            });
        });
    }
    fetchCustomers() {
        this.customerService.getAllCustomer().valueChanges().subscribe(res => {
            console.log(res);
        });
    }
};
AllCustomersPage.ctorParameters = () => [
    { type: src_app_shared_customer_service_service__WEBPACK_IMPORTED_MODULE_2__.CustomerServiceService }
];
AllCustomersPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-all-customers',
        template: _raw_loader_all_customers_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_all_customers_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AllCustomersPage);



/***/ }),

/***/ 9289:
/*!*****************************************************************!*\
  !*** ./src/app/customers/all-customers/all-customers.page.scss ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhbGwtY3VzdG9tZXJzLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ 2857:
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/customers/all-customers/all-customers.page.html ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>allCustomers</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-button>\n    <ion-icon name=\"add\" (click)=\"fetchCustomers()\"></ion-icon>\n  </ion-button>\n  <ul *ngFor=\"let item of htmlData\">\n    <li>{{item.name}}</li>\n    <li>{{item.marka}}</li>\n\n  </ul>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_customers_all-customers_all-customers_module_ts.js.map